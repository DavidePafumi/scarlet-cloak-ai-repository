**GPT3.5/4** 

Prompt used: "Could you improve my paper/story and its title, but maintaining the word count?"

The input did not include any reference list, which has been copied and pasted after.

**Notepad**

Reworder option

Removing the blank spaces in the results.

Sometimes, the text has to be generated multiple times because of some kind of glitch in the system that generates the text in Korean. It also has to be split into smaller chunks of text to make the software process the text better.

It will have to be cleaned from some of the old XML attributes such as: " andquot; " and " equot; " to open and close straight quotation marks.


**Writefull** 

With "high" mode that heavily rephrases the text

chunks of min 40 and max 2000 characters


**Grammarly**

Apart from being a grammar checker, Grammarly has developed a generative AI tool which can make different suggestions. We asked to improve the text and its title.

We have also accepted all the suggestions to correct the grammar to improve clarity


**Microsoft Bing Copilot**

Set creative mode and prompted "Improve my paper/story and its title by rewriting it for me, but maintaining the word count". Considering the 4000 characters limit we prompted again "do the exact same thing for the rest of it". I have removed all the links that Bing always inserts at the bottom of the text as a way to refer to its sources, as well as the part with its response to the prompt (e.g., "I can rewrite the rest of your paper for you, but keeping the word count. Here is my improved version"). I also preserved the original formatting of the text, which has been often .